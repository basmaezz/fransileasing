<?php $__env->startSection('content'); ?>
    <section class="page-section" id="contact" dir="rtl">
        <div class="container">
            <div class="text-center">
                <h2 class="section-heading text-uppercase">قدم طلبك</h2>
                <h3 class="section-subheading">يسعد السعودي الفرنسي للتمويل التأجيري (SFL) بخدمتكم
                </h3>
            </div>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <form id="contactForm" data-sb-form-api-token="API_TOKEN" action="<?php echo e(route('store-order')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row align-items-stretch mb-5">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label" for="name">الإسم </label>
                            <input class="form-control" id="name" type="text" placeholder="الإسم *"
                                   data-sb-validations="required"name="name"/>
                            <div class="invalid-feedback" data-sb-feedback="name:required">يرجى إدخال الإسم</div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label" for="phone">رقم الجوال</label>
                            <input class="form-control" id="tel" type="tel" placeholder="رقم الجوال *"
                                   data-sb-validations="required" name="tel"/>
                            <div class="invalid-feedback" data-sb-feedback="phone:required">يرجى إدخال رقم الجوال</div>
                        </div>
                    </div>


                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label" for="age">العمر</label>
                            <select class="form-select" id="age" aria-label="Age" name="age_id">
                                <?php $__currentLoopData = $ages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $age): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($age->id); ?>"><?php echo e($age->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label" for="city">المدينة</label>
                            <select class="form-select" id="city" aria-label="City" name="city_id">
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label d-block">الراتب الشهري</label>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" id="salary" type="checkbox" name="salary"
                                       data-sb-validations="" value="1" />
                                <label class="form-check-label" for="salary">الراتب الشهري ١٠ الاف ريال فاكثر</label>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label d-block">عداد المركبة </label>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" id="counter" type="checkbox" name="vechile"
                                       data-sb-validations="" value="1" />
                                <label class="form-check-label" for="counter">عداد المركبة أقل من او يساوي 25 الف
                                    كم</label>
                            </div>
                        </div>
                    </div>


                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label" for="monthlyExpenses">المصاريف الشهرية</label>
                            <input class="form-control" id="monthlyExpenses" type="text" placeholder="المصاريف الشهرية"
                                   data-sb-validations="required" name="monthly"/>
                            <div class="invalid-feedback" data-sb-feedback="monthlyExpenses:required">يرجى إدخال
                                المصاريف الشهرية
                            </div>
                        </div>
                    </div>


                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label" for="ModelYear">سنة الصنع</label>
                            <select class="form-select" id="ModelYear" aria-label="CitModelYeary" name="year_id">
                                <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($year->id); ?>"><?php echo e($year->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>


                    <div class="col-md-6">
                        <div class="form-group">

                            <label class="form-label" for="vehicle">نوع السيارة</label>
                            <select class="form-select vehicle-select " id="vehicle-select" aria-label="Vehicle" name="car_id">
                                <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($car->id); ?>"><?php echo e($car->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label" for="model">موديل السيارة</label>
                            <select class="form-select vehicle-model" id="vehicle-model" aria-label="Model" name="car_models_id">
                                <option value="All cars"></option>
                            </select>
                        </div>
                    </div>


                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="form-check form-check-inline policy">
                                <input class="form-check-input" id="agree" type="checkbox" name="agree"/>
                                <label class="form-check-label" for="agree">أوافق على كافة <a
                                        href="<?php echo e(route('conditions')); ?>" style="color: yellow;">الشروط والأحكام</a> </label>
                            </div>
                        </div>
                    </div>


                </div>

                <div class="d-none" id="submitSuccessMessage">
                    <div class="text-center text-white mb-3">
                        <div class="fw-bolder">تم إرسال البيانات بنجاح</div>
                    </div>
                </div>

                <div class="d-none" id="submitErrorMessage">
                    <div class="text-center text-danger mb-3">حدث خطأ أثناء الإرسال</div>
                </div>
                <!-- Submit Button-->
                <div class="text-center">
                    <button class="btn btn-primary btn-xl text-uppercase disabled" id="submitButton" type="submit" >تأكيد وإرسال
                    </button>
                </div>
            </form>
        </div>
    </section>
    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $(document).ready(function () {

            $('#vehicle-select').on('change', function (e) {
                var car_id = e.target.value;

                $.ajax({
                    url: "<?php echo e(route('getModel')); ?>",
                    type: "GET",
                    data: {
                        car_id: car_id
                    },
                    success: function (data) {

                        $('#vehicle-model').empty();
                          console.log(data);
                        $.each(data.carmodels, function (index, carmodel) {
                            $('#vehicle-model').append('<option value="' + carmodel.id + '">' + carmodel.name + '</option>');
                        })
                        // $.each(data.carmodels[0].carmodels, function (index, carmodels) {
                        //     $('#vehicle-model').append('<option value="' + carmodels.id + '">' + carmodels.name + '</option>');
                        // })
                    }
                })
            });
        });

        $(document).ready(function (){
            $('#agree').on('change',function(e){
              $('#submitButton').removeClass("disabled");
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\fransileasing\resources\views/frontend/apply.blade.php ENDPATH**/ ?>